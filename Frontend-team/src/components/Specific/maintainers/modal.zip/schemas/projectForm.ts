import { z } from 'zod';

export const projectFormSchema = z.object({
  title: z.string().min(1, 'Project name is required'),
  type: z.string().min(1, 'Short description is required'),
  description: z.string().min(1, 'Long description is required'),
  rewards: z.array(z.string().url('Must be a valid URL')),
  projectLeads: z.array(z.string()),
  skillsRequired: z.array(z.string()),
  skillCategory: z.string().min(1, 'Skill category is required'),
  experienceLevel: z.string().min(1, 'Skill level is required')
});