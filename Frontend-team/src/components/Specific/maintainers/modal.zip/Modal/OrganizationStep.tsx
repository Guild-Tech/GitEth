import React from 'react';
import { Plus, Check } from 'lucide-react';

interface Organization {
  id: string;
  name: string;
  avatar: string;
}

interface OrganizationStepProps {
  availableOrgs: Organization[];
  installedOrgs: Organization[];
  onSelectOrg: (orgId: string) => void;
  selectedOrgs: string[];
}

export function OrganizationStep({
  availableOrgs,
  installedOrgs,
  onSelectOrg,
  selectedOrgs,
}: OrganizationStepProps) {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-2">Choose Github Organisations</h2>
      <p className="text-gray-600 mb-6">
        Create an organisation on github containing the repositories you want to add
      </p>

      <div className="space-y-6">
        <section>
          <h3 className="text-lg font-medium mb-4">Available Organisations</h3>
          {availableOrgs.length > 0 ? (
            <div className="space-y-3">
              {availableOrgs.map((org) => (
                <button
                  key={org.id}
                  onClick={() => onSelectOrg(org.id)}
                  className="w-full flex items-center justify-between p-4 rounded-lg border border-gray-200 hover:border-purple-200 hover:bg-purple-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={org.avatar}
                      alt=""
                      className="w-10 h-10 rounded-full"
                    />
                    <span className="font-medium">{org.name}</span>
                  </div>
                  <Plus className="w-5 h-5 text-gray-400" />
                </button>
              ))}
            </div>
          ) : (
            <div className="text-gray-500 p-4 rounded-lg border border-gray-200">
              You have no organization available.
            </div>
          )}
        </section>

        <section>
          <h3 className="text-lg font-medium mb-4">
            Installed on these Organisations
          </h3>
          {installedOrgs.length > 0 ? (
            <div className="space-y-3">
              {installedOrgs.map((org) => (
                <div
                  key={org.id}
                  className="w-full flex items-center justify-between p-4 rounded-lg border border-gray-200 bg-purple-50 border-purple-200"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={org.avatar}
                      alt=""
                      className="w-10 h-10 rounded-full"
                    />
                    <span className="font-medium">{org.name}</span>
                  </div>
                  <Check className="w-5 h-5 text-purple-600" />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-gray-500 p-4 rounded-lg border border-gray-200">
              You have no organization available.
            </div>
          )}
        </section>
      </div>
    </div>
  );
}