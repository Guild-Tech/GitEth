import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { projectFormSchema } from '../schemas/projectForm';
import type { ProjectFormData, ProjectVisual } from '../types/project';
import { FormField } from '../Form/FormField';
import { FileUpload } from '../Form/FileUpload';
import { LinkInput } from '../Form/LinkInput';
import { SkillsInput } from '../Form/SkillsInput';
import { SelectField } from '../Form/SelectField';
import useProjects from '@/hooks/useProjects';

const SKILL_LEVELS = ['Beginner', 'Intermediate', 'Expert'];
const SKILL_CATEGORIES = ['Frontend', 'Backend', 'Design', 'DevOps', 'Mobile'];

interface ProjectDetailsStepProps {
  onSubmit: (data: ProjectFormData) => void;
}

export function ProjectDetailsStep({ onSubmit }: ProjectDetailsStepProps) {
  const [visual, setVisual] = useState<ProjectVisual>(null);
  const [links, setLinks] = useState<string[]>([]);
  const [newLink, setNewLink] = useState('');
  const [skills, setSkills] = useState<string[]>(['Design']);
  const {createProject} = useProjects()

  const { register, handleSubmit, control, formState: { errors } } = useForm<ProjectFormData>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      type:"paid",
      skillsRequired: ['Design'],
      experienceLevel: 'Expert'
    }
  });

  const handleVisualUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVisual(file);
    }
  };

  const handleAddLink = () => {
    if (newLink && !links.includes(newLink)) {
      setLinks([...links, newLink]);
      setNewLink('');
    }
  };

  const handleRemoveLink = (linkToRemove: string) => {
    setLinks(links.filter(link => link !== linkToRemove));
  };

  const handleAddSkill = (skill: string) => {
    if (!skills.includes(skill)) {
      setSkills([...skills, skill]);
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter(skill => skill !== skillToRemove));
  };

  const onFormSubmit = async(data: ProjectFormData) => {

    const formData = {
      ...data,
      links,
      preferredSkills: skills
    };
    onSubmit(formData);
    console.log('Form submitted:', formData);
    const x = await createProject(formData)
    console.log(x)
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-2">Tell us About Your Project</h2>
      <form className="space-y-6" onSubmit={handleSubmit(onFormSubmit)}>
        <FormField label="Project Name" error={errors.title?.message}>
          <input
            {...register('title')}
            type="text"
            placeholder="ShxtsnGigs"
            className="w-full p-3 rounded-lg border  text-black border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </FormField>

        <FormField label="Short Description" error={errors.shortDescription?.message}>
          <input
            {...register('shortDescription')}
            type="text"
            placeholder="Shortly describe your project"
            className="w-full p-3 rounded-lg border text-black border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </FormField>

        <FormField label="Long Description" error={errors.description?.message}>
          <textarea
            {...register('description')}
            placeholder="Elaborate on your project"
            className="w-full p-3 rounded-lg border text-black border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"
            rows={4}
          />
        </FormField>

        <FormField label="Project Visual">
          <FileUpload onUpload={handleVisualUpload} />
        </FormField>

        <FormField label="Links">
          <LinkInput
            links={links}
            newLink={newLink}
            onNewLinkChange={setNewLink}
            onAddLink={handleAddLink}
            onRemoveLink={handleRemoveLink}
          />
        </FormField>

        <FormField label="Project Leads">
          <SelectField
            name="projectLeads"
            control={control}
            options={[]}
            placeholder="Pick a contributor or type in Github handle"
          />
        </FormField>

        <FormField label="Choose your Preferred Skills">
          <SkillsInput
            skills={skills}
            onAddSkill={handleAddSkill}
            onRemoveSkill={handleRemoveSkill}
          />
        </FormField>

        <FormField label="Skills Category" error={errors.skillCategory?.message}>
          <SelectField
            name="skillCategory"
            control={control}
            options={SKILL_CATEGORIES}
            placeholder="Select"
          />
        </FormField>

        <FormField label="Skill Levels" error={errors.skillLevel?.message}>
          <SelectField
            name="skillLevel"
            control={control}
            options={SKILL_LEVELS}
          />
        </FormField>

        <button
          type="submit"
          className="w-full py-3 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
        >
          Submit
        </button>
      </form>
    </div>
  );
}