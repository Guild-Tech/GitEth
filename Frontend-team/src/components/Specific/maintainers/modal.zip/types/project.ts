export interface ProjectFormData {
  title: string;
  type: string;
  description: string;
  rewards: string;
  experienceLevel: string;
  skillsRequired: string[];
  projectImage: File | null;
  // skillLevel: string;
}

export type ProjectVisual = File | null;